﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player1 : MonoBehaviour
{
    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    Rigidbody2D rb;

    //zivoty
    public Text healthTextP1;
    private int health = 3;
    Boolean isDead = false;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //CheckIfDead();
        Invoke("CheckIfDead", 3f);
        CheckIfOut();

        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player1") * movementSpeed;

        //otacanie postavicky
        if (movement < 0)
        {
            this.GetComponent<SpriteRenderer>().flipX = false;
        }
        else
        {
            this.GetComponent<SpriteRenderer>().flipX = true;
        }

    }

    void LateUpdate()
    {
        isDead = false;
    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }

   void CheckIfDead()
    {
        if (CameraFollow.platPos - 20 >= rb.position.y && !isDead)
        {
            if (health == 1) {
                //SceneManager.LoadScene("Multiplayer");
                //CameraFollow.platPos = 0;

                Debug.Log("Si uplne dead P1");
            }
            else
            {
                isDead = true;
                Debug.Log("Si dead P1");
                health--;
                healthTextP1.text = Mathf.Round(health).ToString();
                rb.transform.position = new Vector2(Player2.p1PosX + 0.5f, Player2.p1PosY);
            }
            
        }
    }

    void CheckIfOut()
    {
        if (rb.position.x > 5)
        {
            rb.transform.position = new Vector2(-5, rb.position.y);
        }
        else if (rb.position.x < -5)
        {
            rb.transform.position = new Vector2(5, rb.position.y);
        }
    }
}
