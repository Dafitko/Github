﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    public GameObject platformPrefab;
    public GameObject specialPlatformPrefab;
    public GameObject Player2;
    public GameObject Player1;

    public float levelWidth = 3.5f;
    public float minY = .3f;
    public float maxY = .6f;
    public static float platPos;
    float a = 5.2f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //generovanie platforiem
        if (collision.gameObject.name.StartsWith("Platform"))
        {

             if(Random.Range(1,10) == 1)
            {
                Destroy(collision.gameObject);
                Instantiate(specialPlatformPrefab, new Vector2(Random.Range(-levelWidth, +levelWidth),  CameraFollow.platPos + (a + Random.Range(minY, maxY))), Quaternion.identity);
            }
            else
            {
                collision.gameObject.transform.position = new Vector2(Random.Range(-levelWidth, +levelWidth), CameraFollow.platPos + (a + Random.Range(minY, maxY)));
            }

        }else if (collision.gameObject.name.StartsWith("Special"))
        {

            if (Random.Range(1, 10) == 1)
            {

                collision.gameObject.transform.position = new Vector2(Random.Range(-levelWidth, +levelWidth), CameraFollow.platPos + (a + Random.Range(minY, maxY)));

                
            }
            else
            {
                Destroy(collision.gameObject);
                Instantiate(platformPrefab, new Vector2(Random.Range(-levelWidth, +levelWidth), CameraFollow.platPos + (a + Random.Range(minY, maxY))), Quaternion.identity);
            }

        }


        

        
    }
}
