﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player2 : MonoBehaviour
{

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    //zivoty
    public Text healthTextP2;
    private int health = 3;
    Boolean isDead = false;

    Rigidbody2D rb;

    public static float p1PosY;
    public static float p1PosX;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        CheckIfDead();
        CheckIfOut();

        p1PosY = rb.position.y;
        p1PosX = rb.position.x;
        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player2") * movementSpeed;


        //otacanie postavicky
        if(movement < 0)
        {
            this.GetComponent<SpriteRenderer>().flipX = false;
        }
        else
        {
            this.GetComponent<SpriteRenderer>().flipX = true;
        }
    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }

    void CheckIfDead()
    {
        if (CameraFollow.platPos - 15 > rb.position.y && !isDead)
        {
            isDead = true;
            Debug.Log("Si dead P2");
            health--;
            healthTextP2.text = Mathf.Round(health).ToString();
            SceneManager.LoadScene("Multiplayer");
            CameraFollow.platPos = 0;
            
        }
    }

    void CheckIfOut()
    {
        if (rb.position.x > 5)
        {
            rb.transform.position = new Vector2(-5,rb.position.y);
        }
        else if (rb.position.x < -5)
        {
            rb.transform.position = new Vector2(5, rb.position.y);
        }
    }
}
