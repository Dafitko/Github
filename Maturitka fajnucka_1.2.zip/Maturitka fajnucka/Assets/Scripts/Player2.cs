﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player2 : MonoBehaviour
{

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    Rigidbody2D rb;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player2") * movementSpeed;
    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }
}
