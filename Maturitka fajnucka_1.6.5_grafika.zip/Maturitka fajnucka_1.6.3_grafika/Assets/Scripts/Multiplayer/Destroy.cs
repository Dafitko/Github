﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    public GameObject platformPrefab;

    public float levelWidth = 3.5f;
    public float minY = .3f;
    public float maxY = 0.6f;
    public static float platPos;
    float a = 14f;

                                            
        void OnTriggerEnter2D(Collider2D collision)
        {          
                gameObject.transform.position = new Vector2(Random.Range(-levelWidth, +levelWidth), gameObject.transform.position.y + (a + Random.Range(minY, maxY)));
        }
    
}
