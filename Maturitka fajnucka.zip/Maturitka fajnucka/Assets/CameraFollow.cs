﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    //kamera sa hybe iba smerom nahor cize menit sa bude iba pozitivne Y, ak hrac spadne dole tak smola

    //premenna ktora je referenciou pre nasho hraca a jeho pohyb
    public Transform target;

    // LateUpdate -> pouzivame tuto metodu pretoze chceme aby nasa kamera bola stale trochu "neskor" za hracom, 
    //ak by tam bol normalny update tak by sa posunul hrac a hned za nim kamera,
    //hrac a hned za nim kamera  pretoze su v ronakej funkcii update to sposobuje to zasekavanie ktoremu sa vyhneme pomocou LateUpdate
    //hrac sa pohybuje vo funkcii update a fixedupdate a kamera v lateupdate
    void LateUpdate()
    {
        //kontrolujeme ci Y hodnota trageta je vacsia ako Y hodnota kamery
        if (target.position.y > transform.position.y)
        {   
            //nastavenie pozicie -> nahradzujeme Y poziciu kamery Y poziciou targetu
            Vector3 newPos = new Vector3(transform.position.x, target.position.y, transform.position.z);

            //Lepring je funkcia ktora yosmoothuje pohyb kamery, prve je pozicia z ktoru chceme jemne transformovat, potom nova pozicia a potom rychlost transformacie->je to prec
            //Vector 3 nie je stavany na Lerping namiesto toho sa pouziva smoothDamp ->je to prec
            transform.position = newPos;
        }
    }
}
