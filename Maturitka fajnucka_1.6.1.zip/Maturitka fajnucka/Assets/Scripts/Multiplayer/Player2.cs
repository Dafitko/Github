﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player2 : MonoBehaviour
{

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    //zivoty
    public Text healthTextP2;
    private int health = 3;

    Rigidbody2D rb;

    public static float p2PosY;
    public static float p2PosX;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    private void Update()
    {

        p2PosY = rb.position.y;
        p2PosX = rb.position.x;

        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player2") * movementSpeed;

    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        StartCoroutine(CheckIfDead());
        CheckIfOut();


        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }

    private IEnumerator CheckIfDead()
    {
        if (CameraFollow.platPos - 10 > rb.position.y)
        {
            
            if (health == 1)
            {
                SceneManager.LoadScene("MainMenu");
                CameraFollow.platPos = 0;

                Debug.Log("Si uplne dead P2");
            }
            else
            {
                Debug.Log("Si dead P2");
                health--;
                healthTextP2.text = Mathf.Round(health).ToString();
                rb.transform.position = new Vector2(Player1.p1PosX + 0.5f, Player1.p1PosY);
            }
        yield return new WaitForSeconds(1);

        }
    }

    private void CheckIfOut()
    {
        if (rb.position.x > 5)
        {
            rb.transform.position = new Vector2(-5,rb.position.y);
        }
        else if (rb.position.x < -5)
        {
            rb.transform.position = new Vector2(5, rb.position.y);
        }
    }
}
