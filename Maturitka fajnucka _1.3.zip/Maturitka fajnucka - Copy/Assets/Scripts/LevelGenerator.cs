﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerator : MonoBehaviour
{

    public GameObject platformPrefab;
    public GameObject levelEdge;

    public int numberOfPlatforms = 6;
    public float levelWidth = 3f;
    public float minY = .4f;
    public float maxY = 1.5f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private bool isActivated = false;

    void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (!this.isActivated && collision.gameObject.tag == "Player")
        {
            this.isActivated = true;

            //kolko platforiem potrebujeme
            for (int i = 0; i < numberOfPlatforms; i++)
            {
                //posledne znamena ze nebudeme rotovat s objektom
                //klonovanie objektov

                //spawnujem platformy a zvysujem Y hodnotu pomocou random v danom rozsahu
                CameraFollow.platformSpawn.y += Random.Range(minY, maxY);
                CameraFollow.platformSpawn.x = Random.Range(-levelWidth, +levelWidth);
                Instantiate(platformPrefab, CameraFollow.platformSpawn, Quaternion.identity);
            }

            Instantiate(levelEdge,new Vector3(0,this.gameObject.transform.position.y + 4), Quaternion.identity);
        } 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
