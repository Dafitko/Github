﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthP1 : MonoBehaviour
{
    public static int healthP1 = 3;
    public int numOfHearts;

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    private void FixedUpdate()
    {

        if (healthP1 > numOfHearts)
        {
            healthP1 = numOfHearts;
        }

        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < healthP1)
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;
            }


            if (i < numOfHearts)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }
        }
    }

    public static int getHeartP1()
    {
        return healthP1;
    }
    public static void minusHeartP1()
    {
        healthP1 = healthP1 - 1;
    }

    public static void plusHeartP1()
    {
        if (healthP1 == 3)
        {
            healthP1 = 3;
        }
        else { 
            healthP1 = healthP1 + 1;
        }
    }

    public static void setHeartP1(int num)
    {
        healthP1 = num;
    }
}
