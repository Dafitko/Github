﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour
{
    public static int healthP2 = 3;
    public int numOfHearts;

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    private void FixedUpdate()
    {

        if (healthP2 > numOfHearts)
        {
            healthP2 = numOfHearts;
        }

        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < healthP2)
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;
            }


            if (i < numOfHearts)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }
        }
    }

    public static int getHeart()
    {
        return healthP2;
    }
    public static void minusHeartP2()
    {
        healthP2 = healthP2 - 1;
    }

    public static void plusHeartP2()
    {
        if (healthP2 == 3)
        {
            healthP2 = 3;
        }
        else
        {
            healthP2 = healthP2 + 1;
        }
    }

    public static void setHeartP2(int num)
    {
        healthP2 = num;
    }
}
