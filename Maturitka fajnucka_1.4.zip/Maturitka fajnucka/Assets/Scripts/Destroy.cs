﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    public GameObject platformPrefab;
    public GameObject player;

    public float levelWidth = 3f;
    public float minY = .5f;
    public float maxY = 1f;
    public static float platPos;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {

        }
        else
        {
            Instantiate(platformPrefab, new Vector2(Random.Range(-levelWidth,+levelWidth), CameraFollow.platPos + (4 + Random.Range(minY,maxY))), Quaternion.identity);
            Destroy(collision.gameObject);
        }
    }
}
