﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchCharacter : MonoBehaviour
{
    public GameObject router, server, Switch, pc;

    private SwitchCharacter2 player2;
    static bool start = false;

    public static int p1avatarOn = 1;
    int p2avatarOn = 2;

    void Start()
    {
        pc.gameObject.SetActive(false);
        server.gameObject.SetActive(false);
        router.gameObject.SetActive(true);
        Switch.gameObject.SetActive(false);
        SwitchAvatarP1();
        player2.GetP1Avatar(p1avatarOn);
    }

    void Awake()
    {
        player2 = GameObject.FindObjectOfType<SwitchCharacter2>();
    }

    public void GetP2Avatar(int avatar)
    {
        p2avatarOn = avatar;
    }

 
    public void SwitchAvatarP1()
    {
        
        switch (p1avatarOn)
        {
            case 1:
                if (start == false)
                {
                    start = true;
                    p1avatarOn = 1;
                    Debug.Log("prskocil som mod");
                    break;
                }
                if (p2avatarOn == 2)
                {
                    p1avatarOn = 2;
                    SwitchAvatarP1();
                }
                else
                {
                    p1avatarOn = 2;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(true);
                    Switch.gameObject.SetActive(false);
                    
                }
                
                //Debug.Log("plazer 1"+p1avatarOn);
                //Debug.Log("player 2"+p2avatarOn);
                break;
           
            case 2:

                if (p2avatarOn == 3)
                {
                    p1avatarOn = 3;
                    SwitchAvatarP1();
                }
                else
                {
                    p1avatarOn = 3;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(true);
                    
                }
                Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                
                break;
            
            case 3:
                if (p2avatarOn == 4)
                {
                    p1avatarOn = 4;
                    SwitchAvatarP1();
                    
                }
                else
                {
                    p1avatarOn = 4;
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);
                    pc.gameObject.SetActive(true);

                }
                Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                break;

            case 4:
                if (p2avatarOn == 1)
                {
                    p1avatarOn = 1;
                    SwitchAvatarP1();

                }
                else
                {
                    p1avatarOn = 1;
                    router.gameObject.SetActive(true);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);
                    pc.gameObject.SetActive(false);

                }
                Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                break;
        }

        player2.GetP1Avatar(p1avatarOn);
    }

}
