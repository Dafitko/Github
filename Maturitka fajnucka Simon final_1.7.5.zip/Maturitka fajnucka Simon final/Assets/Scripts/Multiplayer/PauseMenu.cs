﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour
{
    public static bool GameiSPaused = false;

    public GameObject pauseMenuUI;

    public Text highestText;

    public Text highestTextDeadMenu;
    public Text scoreTextDeadMenu;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (GameiSPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }

    void FixedUpdate()
    {
        highestText.text = CameraFollow.highestScore.ToString();
        highestTextDeadMenu.text = CameraFollow.highestScore.ToString();
        scoreTextDeadMenu.text = CameraFollow.topScoreMulti.ToString();
    }

    public void Resume()
    {
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameiSPaused = false;
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        GameiSPaused = true;
    }

    public void LoadMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
        GameiSPaused = false;
        pauseMenuUI.SetActive(false);
    }
    public void LoadSingle()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Singleplayer");
    }

    public void LoadMulti()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Multiplayer");
    }

    public void QuitGame()
    {
        Debug.Log("Quit");
        Application.Quit();
    }

}
