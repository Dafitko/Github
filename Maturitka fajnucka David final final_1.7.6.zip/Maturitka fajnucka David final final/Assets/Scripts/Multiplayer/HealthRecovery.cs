﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthRecovery : MonoBehaviour
{
    public Transform heart;
    public Transform destroyer;

    private void Start()
    {
        heart.transform.position = new Vector2(Random.Range(-4, 4), 50);
    }

    private void Update()
    {
        Klesanie();

        if (destroyer.position.y >= heart.position.y)
        {
            heart.transform.position = new Vector2(Random.Range(-4, 4), (heart.position.y + 50));
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Player2")
        {
            Health.plusHeartP2();
            Debug.Log("Hrac 2 ma o 1 HP viac.");

            heart.transform.position = new Vector2(Random.Range(-4, 4), (heart.position.y + 50));
        }
        else if (collision.gameObject.name == "Player1")
        {
            HealthP1.plusHeartP1();
            Debug.Log("Hrac 1 ma o 1 HP viac.");

            heart.transform.position = new Vector2(Random.Range(-4, 4), (heart.position.y + 50));
        }

    }

    void Klesanie()
    {
        heart.transform.position = new Vector2(heart.position.x, (heart.position.y - 0.07f));
    }
}
