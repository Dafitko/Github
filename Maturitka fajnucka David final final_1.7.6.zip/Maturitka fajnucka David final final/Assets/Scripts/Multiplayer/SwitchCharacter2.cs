﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchCharacter2 : MonoBehaviour
{
    public GameObject router, server, Switch, pc;
      
    private SwitchCharacter player1;
    static bool start = false;

    int p1avatarOn =1;
    public static int p2avatarOn = 2;

    void Start()
    {
        pc.gameObject.SetActive(false);
        server.gameObject.SetActive(true);
        router.gameObject.SetActive(false);
        Switch.gameObject.SetActive(false); 
        SwitchAvatarP2();
        player1.GetP2Avatar(p2avatarOn);
    }

    void Awake()
    {
        player1 = GameObject.FindObjectOfType<SwitchCharacter>();
    }

    public void GetP1Avatar(int avatar) {
        p1avatarOn = avatar;
    }

        
    public void SwitchAvatarP2()
    {
        
        switch (p2avatarOn)
        {
            case 1:
                if (p1avatarOn == 2)
                {
                    p2avatarOn = 2;
                    SwitchAvatarP2();
                }
                else {
                    p2avatarOn = 2;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(true);
                    Switch.gameObject.SetActive(false);
                   
                }
                
                Debug.Log("plazer 1"+p1avatarOn);
                Debug.Log("player 2"+p2avatarOn);
                break;
           
            case 2:
                if (start == false)
                {
                    start = true;
                    p2avatarOn = 2;
                    break;
                }
                if (p1avatarOn == 3)
                {
                    p2avatarOn = 3;
                    SwitchAvatarP2();
                }
                else
                {
                    p2avatarOn = 3;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(true);
                    
                }
                    Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                
                break;
            case 3:
                if (p1avatarOn == 4)
                {
                    p2avatarOn = 4;
                    SwitchAvatarP2();
                }
                else
                {
                    p2avatarOn = 4;
                    pc.gameObject.SetActive(true);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);
                    
                }
                Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                break;

            case 4:
                if (p1avatarOn == 1)
                {
                    p2avatarOn = 1;
                    SwitchAvatarP2();
                }
                else
                {
                    p2avatarOn = 1;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(true);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);

                }
                Debug.Log("plazer 1" + p1avatarOn);
                Debug.Log("player 2" + p2avatarOn);

                break;
        }

        player1.GetP2Avatar(p2avatarOn);
    }
}
