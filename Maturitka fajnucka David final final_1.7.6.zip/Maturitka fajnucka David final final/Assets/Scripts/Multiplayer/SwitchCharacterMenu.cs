﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchCharacterMenu : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("MultiPlayer");
    }
    public void PlaySingle()
    {
        SceneManager.LoadScene("SinglePlayer");
    }

    public void MainMenu() { 
            SceneManager.LoadScene("MainMenu");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) MainMenu();
       

    }


}
