﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour
{
    public static AudioClip jumpSound, bounceSound, button;

    static AudioSource audioSrc;

    // Start is called before the first frame update
    void Start()
    {
        jumpSound = Resources.Load <AudioClip> ("jump");
        bounceSound = Resources.Load<AudioClip>("bounce");
        button = Resources.Load<AudioClip>("buttonclick");
        audioSrc = GetComponent<AudioSource>();
    }

    public static void PlaySound(string clip) { 
        switch(clip){
        case "jump": 
            audioSrc.PlayOneShot(jumpSound);
            //Debug.Log("JUMPING");
            break;

        case "bounce":
            audioSrc.PlayOneShot(bounceSound);
            //Debug.Log("JUMPIN");
            break;

        /*case "button":
                audioSrc.PlayOneShot(button);
                break;*/
        }
    }
}
