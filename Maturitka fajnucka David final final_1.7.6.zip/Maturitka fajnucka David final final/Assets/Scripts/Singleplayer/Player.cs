﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player : MonoBehaviour
{

    //*************************************************************  Pridal SImon
    Animator anim;
    private bool collision = false;
    private bool facingLeft;

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    //zivoty
    public Text healthTextP2;

    static Rigidbody2D rb2;

    public GameObject deadMenu;
    public Transform camera;

    // movement script
    void Awake()
    {
        anim = GetComponent<Animator>();
        anim.SetInteger("character", SwitchCharacterSingle.p1avatarOn);

    }

    void Start()
    {
        facingLeft = true;
        rb2 = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    private void Update()
    {

        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player2") * movementSpeed;

    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        CheckIfDead();
        CheckIfOut();


        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb2.velocity;

        //******************************************
        //Pridal Šimon, collision mi hovorí či narazím na špeciálnu platformu, ak áno spustí druhú animáciu
        //anim.SetBool odosiela údaje animátorovi
        if (collision == true)
        {
            anim.SetBool("collision", collision);

            if (velocity.y <= 4)
            {
                collision = false;
                anim.SetBool("collision", collision);
                Debug.Log("Collision 2 je " + collision);
            }

        }
        anim.SetFloat("velocityY", velocity.y);
        Flip(movement);
        //******************************************


        velocity.x = movement;
        rb2.velocity = velocity;

    }

    //Metóda na príjamnie true od SpecialPlatform scriptu
    public void updateCollision(bool coll)
    {
        collision = coll;
        /*Debug.Log("Coll je "+ coll);
        Debug.Log("Collision je " + collision);*/
    }

    //otáča hráča zo strany na stranu do ľava do prava
    //zisťujeme či sa hýbe do ľava či do prava a na základe toho meníme hodnotu (-+1) Scale v Unity
    private void Flip(float flip)
    {
        if (movement < 0 && !facingLeft || movement > 0 && facingLeft)
        {
            facingLeft = !facingLeft;

            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
    }

    private void CheckIfDead()
    {
        if (camera.position.y - 10 > rb2.position.y)
        {

            if (Health.getHeart() <= 1)
            {
                Debug.Log("Si uplne dead P2");
                //SceneManager.LoadScene("MainMenu");
                Health.setHeartP2(3);
                HealthP1.setHeartP1(3);
                rb2.transform.position = new Vector2(0.6f, -3f);

                Time.timeScale = 0f;
                deadMenu.SetActive(true);
            }
            else
            {
                Debug.Log("Si dead P2");
                Health.minusHeartP2();


                rb2.transform.position = new Vector2(Player1.getP1PosX() + 0.5f, Player1.getP1PosY());
            }

        }
    }

    private void CheckIfOut()
    {
        if (rb2.position.x > 7)
        {
            rb2.transform.position = new Vector2(-7, rb2.position.y);
        }
        else if (rb2.position.x < -7)
        {
            rb2.transform.position = new Vector2(7, rb2.position.y);
        }
    }

    public static float getP2PosX()
    {
        return rb2.transform.position.x;
    }
    public static void setP2PosX(float posX)
    {
        rb2.transform.position = new Vector2(posX, rb2.transform.position.y);
    }
    public static float getP2PosY()
    {
        return rb2.transform.position.y;
    }
    public static void setP2PosY(float posY)
    {
        rb2.transform.position = new Vector2(rb2.transform.position.x, posY);
    }
}
