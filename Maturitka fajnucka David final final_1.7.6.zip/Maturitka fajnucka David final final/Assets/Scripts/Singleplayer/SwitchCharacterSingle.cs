﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchCharacterSingle : MonoBehaviour
{
    public GameObject router, server, Switch, pc;

    public static int p1avatarOn;

    void Start()
    {
        p1avatarOn = 4;
        pc.gameObject.SetActive(false);
        server.gameObject.SetActive(false);
        router.gameObject.SetActive(true);
        Switch.gameObject.SetActive(false);
        SwitchAvatarP1();
    }


    public void SwitchAvatarP1()
    {

        switch (p1avatarOn)
        {
            case 1:        
                    p1avatarOn = 2;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(true);
                    Switch.gameObject.SetActive(false);
                break;

            case 2:

                    p1avatarOn = 3;
                    pc.gameObject.SetActive(false);
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(true);

                break;

            case 3:
               
                    p1avatarOn = 4;
                    router.gameObject.SetActive(false);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);
                    pc.gameObject.SetActive(true);
                break;

            case 4:
                
                    p1avatarOn = 1;
                    router.gameObject.SetActive(true);
                    server.gameObject.SetActive(false);
                    Switch.gameObject.SetActive(false);
                    pc.gameObject.SetActive(false);
                break;
        }
    }

}
