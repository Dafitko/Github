﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    //kamera sa hybe iba smerom nahor cize menit sa bude iba pozitivne Y, ak hrac spadne dole tak smola

    //premenna ktora je referenciou pre nasho hraca a jeho pohyb
    public Transform player1;
    public Transform player2;
    public Transform highest;

    public Transform theDestroyer;
    public static float platPos;


    // LateUpdate -> pouzivame tuto metodu pretoze chceme aby nasa kamera bola stale trochu "neskor" za hracom, 
    //ak by tam bol normalny update tak by sa posunul hrac a hned za nim kamera,
    //hrac a hned za nim kamera  pretoze su v ronakej funkcii update to sposobuje to zasekavanie ktoremu sa vyhneme pomocou LateUpdate
    //hrac sa pohybuje vo funkcii update a fixedupdate a kamera v lateupdate
    void LateUpdate()
    {
        //ktory hrac je vyssie -> podla neho sa hybe kamera
        if(highest.position.y < player1.position.y || highest.position.y < player2.position.y) { 
            if(player1.position.y > player2.position.y)
            {
                highest = player1;
            }
            else if(player1.position.y < player2.position.y)
            {
                highest = player2;

                //ak sa pozicie rovnaju tak je jedno z ktoreho hraca sa pozicia zapise
            }
            else if(player1.position.y == player2.position.y)
            {
                highest = player2;
            }
        }

        //kontrolujeme ci Y hodnota trageta je vacsia ako Y hodnota kamery
        if (highest.position.y > transform.position.y)
        {   
            //nastavenie pozicie -> nahradzujeme Y poziciu kamery Y poziciou targetu
            Vector3 newPos = new Vector3(transform.position.x, highest.position.y, transform.position.z);
            Vector3 destroyPos = new Vector3(transform.position.x, highest.position.y - 5, transform.position.z);
            platPos = highest.position.y;

            //Lepring je funkcia ktora yosmoothuje pohyb kamery, prve je pozicia z ktoru chceme jemne transformovat, potom nova pozicia a potom rychlost transformacie->je to prec
            //Vector 3 nie je stavany na Lerping namiesto toho sa pouziva smoothDamp ->je to prec
            transform.position = newPos;
            theDestroyer.position = destroyPos;
            
        }
    }
}
