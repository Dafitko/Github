﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player1 : MonoBehaviour
{
    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    public Transform player1;
    public Transform player2;

    float movement = 0f;

    Rigidbody2D rb;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player1") * movementSpeed;
        //Debug.Log(player1.transform.position.x);

        if (4.15 == player1.transform.position.x || -4.15 == player1.transform.position.x)
        {
            player1.transform.position = player2.transform.position;
            Debug.Log("si tam");
        }
    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }
}
