﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player2 : MonoBehaviour
{

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    //zivoty
    public Text healthTextP2;
    private int health = 3;

    static Rigidbody2D rb2;

    // movement script
    void Start()
    {
        rb2 = GetComponent<Rigidbody2D>();
        
    }

    // Update is called once per frame
    private void Update()
    {

        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player2") * movementSpeed;

    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        StartCoroutine(CheckIfDead());
        CheckIfOut();


        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb2.velocity;
        velocity.x = movement;
        rb2.velocity = velocity;
    }

    private IEnumerator CheckIfDead()
    {
        if (CameraFollow.platPos - 10 > rb2.position.y)
        {
            
            if (Health.getHeart() <= 1)
            {
                Health.setHeart(-3);
                CameraFollow.platPos = 0;
                Debug.Log("Si uplne dead P2");
                SceneManager.LoadScene("MainMenu");
            }
            else
            {
                Debug.Log("Si dead P2");
                Health.setHeart(1);


                rb2.transform.position = new Vector2(Player1.getP1PosX() + 0.5f, Player1.getP1PosY());
            }
        yield return new WaitForSeconds(1);

        }
    }

    private void CheckIfOut()
    {
        if (rb2.position.x > 5)
        {
            rb2.transform.position = new Vector2(-5,rb2.position.y);
        }
        else if (rb2.position.x < -5)
        {
            rb2.transform.position = new Vector2(5, rb2.position.y);
        }
    }

    public static float getP2PosX()
    {
        return rb2.transform.position.x;
    }
    public static void setP2PosX(float posX)
    {
        rb2.transform.position = new Vector2(posX, rb2.transform.position.y);
    }
    public static float getP2PosY()
    {
        return rb2.transform.position.y;
    }
    public static void setP2PosY(float posY)
    {
        rb2.transform.position = new Vector2(rb2.transform.position.x, posY);
    }
}
