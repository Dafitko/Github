﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player1 : MonoBehaviour
{
    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    static Rigidbody2D rb;

    //zivoty
    public Text healthTextP1;
    private int health = 3;
    private Boolean isDead = false;

    // movement script
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    private void Update()
    {

        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player1") * movementSpeed;

    }

    void LateUpdate()
    {
    }

    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        StartCoroutine(CheckIfDead());
        CheckIfOut();



        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;
        velocity.x = movement;
        rb.velocity = velocity;
    }

    private IEnumerator CheckIfDead()
    {


        if (CameraFollow.platPos - 10 > rb.position.y && !isDead)
        {
            if (health == 1) {
                CameraFollow.platPos = 0;
                Debug.Log("Si uplne dead P1");
                SceneManager.LoadScene("MainMenu");
            }
            else
            {
                //isDead = true;
                Debug.Log("Si dead P1");
                health--;
                healthTextP1.text = Mathf.Round(health).ToString();
                rb.transform.position = new Vector2(Player2.getP2PosX() + 0.5f, Player2.getP2PosY());
            }
            yield return new WaitForSeconds(1);


        }
    }

    private void CheckIfOut()
    {
        if (rb.position.x > 5)
        {
            rb.transform.position = new Vector2(-5, rb.position.y);
        }
        else if (rb.position.x < -5)
        {
            rb.transform.position = new Vector2(5, rb.position.y);
        }
    }
    public static float getP1PosX() {
        return rb.transform.position.x;
    }
    public static void setP1PosX(float posX) {
        rb.transform.position = new Vector2(posX, rb.transform.position.y);
    }
    public static float getP1PosY()
    {
        return rb.transform.position.y;
    }
    public static void setP1PosY(float posY)
    {
        rb.transform.position = new Vector2(rb.transform.position.x, posY);
    }
}
