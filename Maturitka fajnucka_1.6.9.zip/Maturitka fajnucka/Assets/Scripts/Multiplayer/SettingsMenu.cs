﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class SettingsMenu : MonoBehaviour
{
    public AudioMixer audioMixer;

    public void SetVolume(float volume)
    {
        audioMixer.SetFloat("Volume", volume);
        PlayerPrefs.SetFloat("Volume", volume);
    }

    public void SetQuality(int qualityIndex)
    {
        PlayerPrefs.SetInt("qualityIndex", qualityIndex);
        QualitySettings.SetQualityLevel(PlayerPrefs.GetInt("qualityIndex"));
    }

    void Awake()
    {
        audioMixer.SetFloat("Volume", PlayerPrefs.GetFloat("Volume"));
    }
}
