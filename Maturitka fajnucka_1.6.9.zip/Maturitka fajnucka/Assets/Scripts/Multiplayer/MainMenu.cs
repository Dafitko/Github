﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{

    public void Multi()
    {
        SceneManager.LoadScene("MultiPlayer");
    }

    public void Single()
    {
        SceneManager.LoadScene("SinglePlayer");
    }

    public void HighScore()
    {
        SceneManager.LoadScene("Highscore");
    }

    public void QuitGame()
    {
        Debug.Log("Quit");
        Application.Quit();
    }
}
