﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialPlatform : MonoBehaviour
{

    //**************** Pridal Simon
    private Player1 player1;
    private Player2 player2;

    private bool coll;
    void Awake()
    {
        player1 = GameObject.FindObjectOfType<Player1>();
        player2 = GameObject.FindObjectOfType<Player2>();
    }

    Animator anim;
    bool bounce = false;

    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {

        anim.SetBool("bounce", bounce);
        if (bounce == true)
        {
            Debug.Log(bounce);
            bounce = false;

        }
    }
    //*******************************
    //*******************

    //premenna sily odrazu
    public float jumpForce = 17f;

    //if collision appears this function will happend
    //bouncing prep -> cele je to nastavenie toho ze nech padame z hociakej vysky tak sila odrazu musi byt rovnaka
    void OnCollisionEnter2D(Collision2D collision)
    {
        
        //iba zistujeme ci ideme z hora(ak by sme to nespravili tak by tam bol taky zasek ked skaceme z jednej platformy cez druhu
        if (collision.relativeVelocity.y <= 0f)
        {
            
            //rigidbody is physics like gravity
            //collider - objekt s ktorym sme sa zrazili
            //mozme pridat sily do nasho rigidbody
            Rigidbody2D rb = collision.collider.GetComponent<Rigidbody2D>();
            //mozme sa zrazit aj s niecim inym co nema rigidbody, cize to musime osetrit(napriklad narazit do druhej platformy ked skaceme)
            if (rb != null)
            {
                bounce = true;

                if (collision.gameObject.name == "Player1")
                {
                    player1.updateCollision(true);
                }
                if (collision.gameObject.name == "Player2")
                {
                    player2.updateCollision(true);
                }


                //addforce berie do uvahy rychlost ktorou sa pohybujeme,ak padame rychlo dole tak potom hore by sme isli velmi pomaly a naopak
                //namiesto toho nastavime rychlost ktorou sa budeme posuvat hore priamo
                //rychlost nasho rigidbody v current state
                Vector2 velocity = rb.velocity; //getting the vector

                //tu mozeme nastavit rychlost ktorou sa hrac odrazi od platformy
                velocity.y = jumpForce; //modifying a component of the vector
                rb.velocity = velocity; //setting back the vector with modified component

                //rb.velocity.y = jumpForce -> toto by nam hodilo error -> nemozeme zmenit component vektora bez zmeny celeho vektora
            }
        }

    }
}
