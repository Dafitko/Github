﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{

    //********************* PRidal Simon
    Animator anim;
    bool bounce = false;

    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
        
        anim.SetBool("bounce", bounce);
        if (bounce == true)
        {
            Debug.Log(bounce);
           bounce = false;
            
        }
    }
    //*******************************


    //premenna sily odrazu
    public float jumpForce = 10f;
    
    //if collision appears this function will happend
    //bouncing prep -> cele je to nastavenie toho ze nech padame z hociakej vysky tak sila odrazu musi byt rovnaka
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            SoundManager.PlaySound("jump");
            //iba zistujeme ci ideme z hora(ak by sme to nespravili tak by tam bol taky zasek ked skaceme z jednej platformy cez druhu
            if (collision.relativeVelocity.y <= 0f)
            {
                //rigidbody is physics like gravity
                //collider - objekt s ktorym sme sa zrazili
                //mozme pridat sily do nasho rigidbody
                Rigidbody2D rb = collision.collider.GetComponent<Rigidbody2D>();
                //mozme sa zrazit aj s niecim inym co nema rigidbody, cize to musime osetrit(napriklad narazit do druhej platformy ked skaceme)
                if (rb != null)
                {
                    bounce = true;
                    //addforce berie do uvahy rychlost ktorou sa pohybujeme,ak padame rychlo dole tak potom hore by sme isli velmi pomaly a naopak
                    //namiesto toho nastavime rychlost ktorou sa budeme posuvat hore priamo
                    //rychlost nasho rigidbody v current state
                    Vector2 velocity = rb.velocity; //getting the vector

                    //tu mozeme nastavit rychlost ktorou sa hrac odrazi od platformy
                    velocity.y = jumpForce; //modifying a component of the vector
                    rb.velocity = velocity; //setting back the vector with modified component

                    //rb.velocity.y = jumpForce -> toto by nam hodilo error -> nemozeme zmenit component vektora bez zmeny celeho vektora
                }
            }
        }

    }
}
