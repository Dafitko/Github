﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//podmienka ze stale tu musi byt rigidbody komponent
[RequireComponent(typeof(Rigidbody2D))]
public class Player1 : MonoBehaviour
{
    //********************************* Pridal Simon
    Animator anim;
    private bool collision = false;
    private bool facingLeft;

    //premenna pre rychlost pohybu do stran
    public float movementSpeed = 8f;

    float movement = 0f;

    public static Rigidbody2D rb;

    public Transform camera;
    public GameObject deadMenu;

    // movement script
    void Start()
    {
        anim = GetComponent<Animator>();
        facingLeft = true; 
        rb = GetComponent<Rigidbody2D>();
        anim.SetInteger("character", SwitchCharacter.p1avatarOn);
    }

    // Update is called once per frame
    private void Update()
    {
        //movement input a zrychlenie pohybu
        movement = Input.GetAxis("Player1") * movementSpeed;

    }


    //ak nastavujeme nieco s fyzikou v pohybe tak sa to robi v nato urcenej metode fixedUpdate 
    void FixedUpdate() //movement here
    {
        CheckIfDead();
        CheckIfOut();
        //zoberieme vektor a zmenime komponent x s nasim inputom co je vlastne pohyb do strany
        Vector2 velocity = rb.velocity;

        //************************ Pridal Šimon
        if (collision == true)
        {
            anim.SetBool("collision", collision);

            if (velocity.y <= 4)
            {
                collision = false;
                anim.SetBool("collision", collision);
                Debug.Log("Collision 2 je " + collision);
            }

        }
        anim.SetFloat("velocityY", velocity.y);

        Flip(movement);
        //***************************

        velocity.x = movement;
        rb.velocity = velocity;

    }

    public void updateCollision(bool coll)
    {
        collision = coll;
        /*Debug.Log("Coll je "+ coll);
        Debug.Log("Collision je " + collision);*/
    }

    //otáča hráča zo strany na stranu do ľava do prava
    //zisťujeme či sa hýbe do ľava či do prava a na základe toho meníme hodnotu (-+1) Scale v Unity
    private void Flip(float flip)
    {
        if (movement < 0 && !facingLeft || movement > 0 && facingLeft)
        {
            facingLeft = !facingLeft;

            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
    }


    private void CheckIfDead()
    {

        if (camera.position.y - 10 > rb.position.y)
        {
            if (HealthP1.getHeartP1() <= 1)
            {

                Debug.Log("Si uplne dead P1");
                //SceneManager.LoadScene("MainMenu");
                HealthP1.setHeartP1(3);
                Health.setHeartP2(3);
                rb.transform.position = new Vector2(0.4f, -3f);

                Time.timeScale = 0f;
                deadMenu.SetActive(true);
            }
            else
            {
                //isDead = true;
                Debug.Log("Si dead P1");
                HealthP1.minusHeartP1();


                rb.transform.position = new Vector2(Player2.getP2PosX() + 0.5f, Player2.getP2PosY());
            }
        }
    }

    private void CheckIfOut()
    {
        if (rb.position.x > 7)
        {
            rb.transform.position = new Vector2(-7, rb.position.y);
        }
        else if (rb.position.x < -7)
        {
            rb.transform.position = new Vector2(7, rb.position.y);
        }
    }
    public static float getP1PosX() {
        return rb.transform.position.x;
    }
    public static void setP1PosX(float posX) {
        rb.transform.position = new Vector2(posX, rb.transform.position.y);
    }
    public static float getP1PosY()
    {
        return rb.transform.position.y;
    }
    public static void setP1PosY(float posY)
    {
        rb.transform.position = new Vector2(rb.transform.position.x, posY);
    }
}
