﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{
    public AudioMixer audioMixer;
    public static float volumeHodnota = 0;
    public Slider volumeSlider;

    public static int muteValue = 0;

    private void Start()
    {
        audioMixer.SetFloat("Volume", volumeHodnota);
        volumeSlider.value = volumeHodnota;
    }

    void FixedUpdate()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            MuteSound();
        }
    }

    public void MuteSound()
    {
        if(muteValue == 1)
        {
            audioMixer.SetFloat("Volume", volumeHodnota);
            muteValue = 0;
        }
        else
        {
            audioMixer.SetFloat("Volume", -80);
            muteValue = 1;
        }
    }

    public void SetVolume(float volume)
    {
        volumeHodnota = volume;
        audioMixer.SetFloat("Volume", volumeHodnota);
    }

    public void SetQuality(int qualityIndex)
    {
        QualitySettings.SetQualityLevel(PlayerPrefs.GetInt("qualityIndex"));
    }

}
